# This file ensures pytest keeps this directory in sys.path,
# so you can run `pytest tests/lib`.
