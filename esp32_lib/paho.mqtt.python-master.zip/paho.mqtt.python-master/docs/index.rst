.. Eclipse paho-mqtt documentation master file, created by
   sphinx-quickstart on Sun Jan 28 11:00:26 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. note::

   This is the documentation of the upcoming 2.0 release of paho-mqtt (already
   available as pre-release). For 1.6.x release of paho-mqtt, see the
   Github README.

.. include:: ../README.rst

.. toctree::
   :hidden:
   :maxdepth: 3

   client
   helpers
   types
   changelog
   migrations
